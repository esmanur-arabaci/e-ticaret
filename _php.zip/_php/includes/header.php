<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arch Aksesuar | Şıklığın ve Estetiğin Buluşma Noktası</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

    <header class="top-header">
        <div class="container">
            <div class="logo">
                <a href="index.php">ARCH AKSESUAR</a> 
            </div>
            
<div class="search-area">
    <form action="arama.php" method="GET">
        <input type="text" placeholder="Takı ara..." name="sorgu" required>
        <button type="submit" class="search-button">Ara</button>
    </form>
</div>
            
            <nav class="top-nav-icons">
<?php


if (isset($_SESSION['oturum_basarili']) && $_SESSION['oturum_basarili'] === true) {
    // KULLANICI GİRİŞ YAPMIŞSA
    ?>
<a href="profil.php" style="font-weight: bold; margin-right: 15px; color: #f0f0f0;"> 
    <i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['ad_soyad']); ?>
</a>
    <a href="cikis.php">ÇIKIŞ YAP</a>
    <?php
} else {
    // KULLANICI GİRİŞ YAPMAMIŞSA
    ?>
    <a href="giris.php">GİRİŞ</a>
    <a href="uye_ol.php">ÜYE OL</a>
    <?php
}
?>
                <a href="sepet.php" class="cart-icon"><i class="fas fa-shopping-cart"></i></a>
            </nav>
            
        </div>
        
    </header>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>

