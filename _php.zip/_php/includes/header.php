<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arch Aksesuar | Şıklığın ve Estetiğin Buluşma Noktası</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

    <header class="top-header">
        <div class="container">
            <div class="logo">
                <a href="index.php">ARCH AKSESUAR</a> 
            </div>
            
            <div class="search-area">
                <input type="text" placeholder="Takı ara...">
                <button class="search-button">Ara</button>
            </div>
            
            <nav class="top-nav-icons">
                <a href="giris.php">GİRİŞ</a>
                <a href="uye_ol.php">ÜYE OL</a>
                <a href="sepet.php" class="cart-icon"><i class="fas fa-shopping-cart"></i></a>
            </nav>
            
        </div>
        
    </header>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>