    <footer class="site-footer">
        <div class="container footer-content">
            
            <div class="footer-logo-social">
                <div class="logo footer-logo">ARCH AKSESUAR</div>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.instagram.com/arc_accessoriesofficial/"><i class="fab fa-instagram"></i></a>
                </div>
            </div>

            <div class="footer-links">
                <h4>MÜŞTERİ HİZMETLERİ</h4>
                <ul>
                    <li><a href="index.php">Sıkça Sorulan Sorular</a></li>
                    <li><a href="index.php">Kargo & Teslimat</a></li>
                    <li><a href="index.php">İade & Değişim</a></li>
                </ul>
            </div>

            <div class="footer-newsletter">
                <h4>BÜLTEN</h4>
                <form>
                    <input type="email" placeholder="email@email.com">
                    <button type="submit">ABONE OL</button>
                </form>
            </div>
        </div>
    </footer>