
    <!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kullanıcı Girişi - Arch Aksesuar</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
<?php include("includes/header.php"); ?>
    
    <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php" >ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" >KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php" >YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php" > ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
   
    <main style="display: flex; justify-content: center; align-items: center; height: 100vh;">
        <div style="
            background-color: var(--color-light-bg);
            padding: 60px;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        ">
            <h2 style="margin-bottom: 25px; color: var(--color-accent);">Hesabınıza Giriş Yapın</h2>

            <form action="login.php" method="POST">
                <div style="margin-bottom: 20px; text-align: left;">
                    <label for="email">E-posta Adresi:</label><br>
                    <input type="email" id="email" name="email" required
                        style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;">
                </div>

                <div style="margin-bottom: 20px; text-align: left;">
                    <label for="password">Şifre:</label><br>
                    <input type="password" id="password" name="password" required
                        style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px;">
                </div>
                <button type="submit"
                    style="width: 100%; padding: 10px; background-color: var(--color-accent); color: var(--color-text-light); border: none; border-radius: 5px; font-weight: bold; cursor: pointer;">
                    Giriş Yap
                </button>

                <p style="margin-top: 15px; font-size: 0.9em;">
                    Hesabınız yok mu? <a href="uye_ol.php" style="color: var(--color-accent); font-weight: bold;">Kayıt olun</a>
                </p>
            </form>
        </div>
    </main>
<?php include("includes/footer.php"); ?>
</body>
</html>
