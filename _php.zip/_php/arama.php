<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_baglanti.php'; 

$arama_sorgusu = isset($_GET['sorgu']) ? trim($_GET['sorgu']) : ''; // URL'den gelen sorguyu alır
$arama_sonuclari = [];

if (!empty($arama_sorgusu)) {
    // Güvenlik için sorguyu hazırlarız
    $arama_terimi = '%' . $baglanti->real_escape_string($arama_sorgusu) . '%';
    
    // SQL Sorgusu: urun_ad VEYA aciklama sütunlarında arama yapar
    $sql = "SELECT id, urun_ad, fiyat, resim_url, aciklama 
            FROM urunler 
            WHERE urun_ad LIKE ? OR aciklama LIKE ?";
            
    $sorgu = $baglanti->prepare($sql);
    // 'ss' arama teriminin iki kez string (metin) olarak kullanılacağını belirtir
    $sorgu->bind_param("ss", $arama_terimi, $arama_terimi);
    $sorgu->execute();
    $sonuc = $sorgu->get_result();

    if ($sonuc && $sonuc->num_rows > 0) {
        while($satir = $sonuc->fetch_assoc()) {
            $arama_sonuclari[] = $satir;
        }
    }
    $sorgu->close();
}
$baglanti->close();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arama Sonuçları: <?php echo htmlspecialchars($arama_sorgusu); ?> - Arch Aksesuar</title>
    <link rel="stylesheet" href="style/style.css"> 
</head>
<body>
<?php include("includes/header.php"); ?>
    
    <nav></nav>

    <main class="container" style="padding: 60px 0;">
        <section class="product-gallery">
            <h2>Arama Sonuçları "<?php echo htmlspecialchars($arama_sorgusu); ?>"</h2> 

            <div class="product-grid">
                
                <?php 
                if (!empty($arama_sonuclari)) {
                    foreach ($arama_sonuclari as $urun) {
                        $detay_linki = "urun_detay.php?id=" . htmlspecialchars($urun['id']);
                    ?>
                    
                    <a href="<?php echo $detay_linki; ?>" class="product-card-link"> 
                        <div class="product-card">
                            
                            <img src="<?php echo htmlspecialchars($urun['resim_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($urun['urun_ad']); ?>" 
                                 class="product-img">
                            
                            <div class="product-info">
                                <h4><?php echo htmlspecialchars($urun['urun_ad']); ?></h4>
                                
                                <p><?php echo number_format($urun['fiyat'], 2, ',', '.') . ' ₺'; ?></p>
                                
                            </div>
                        </div>
                    </a>
                    <?php
                    } 
                } else {
                    echo '<p style="grid-column: 1 / -1; text-align: center;">Aradığınız "' . htmlspecialchars($arama_sorgusu) . '" terimine uygun ürün bulunamadı.</p>';
                }
                ?>
                
            </div>
        </section>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>