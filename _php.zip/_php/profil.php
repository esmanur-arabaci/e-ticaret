<?php
// profil.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_baglanti.php';

// Kullanıcı Giriş Kontrolü
if (!isset($_SESSION['oturum_basarili']) || $_SESSION['oturum_basarili'] !== true) {
    $_SESSION['login_hata'] = "Profilinizi görmek için lütfen giriş yapın.";
    header('Location: giris.php');
    exit();
}

$kullanici_id = $_SESSION['kullanici_id'];
$kullanici_bilgileri = [];
$gecmis_siparisler = [];

// 1. Kullanıcı Temel Bilgilerini Çekme
$sorgu_kullanici = $baglanti->prepare("SELECT ad_soyad, eposta FROM kullanicilar WHERE id = ?");
$sorgu_kullanici->bind_param("i", $kullanici_id);
$sorgu_kullanici->execute();
$sonuc_kullanici = $sorgu_kullanici->get_result();

if ($sonuc_kullanici->num_rows === 1) {
    $kullanici_bilgileri = $sonuc_kullanici->fetch_assoc();
}
$sorgu_kullanici->close();

// 2. Kullanıcının Geçmiş Siparişlerini Çekme
$sql_siparis = "SELECT id, genel_toplam, siparis_tarihi, odeme_yontemi, sehir 
                FROM siparisler 
                WHERE kullanici_id = ? 
                ORDER BY siparis_tarihi DESC";
                
$sorgu_siparis = $baglanti->prepare($sql_siparis);
$sorgu_siparis->bind_param("i", $kullanici_id);
$sorgu_siparis->execute();
$sonuc_siparis = $sorgu_siparis->get_result();

if ($sonuc_siparis->num_rows > 0) {
    while($siparis = $sonuc_siparis->fetch_assoc()) {
        $gecmis_siparisler[] = $siparis;
    }
}
$sorgu_siparis->close();
$baglanti->close();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hesabım - <?php echo htmlspecialchars($_SESSION['ad_soyad'] ?? 'Profil'); ?> - Arch Aksesuar</title>
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<?php include("includes/header.php"); ?>
       <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php" >ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" >KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php" >YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php" > ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    
    <main class="container" style="padding: 60px 0;">
        <h2 style="text-align: center; color: var(--color-accent); margin-bottom: 40px;"><i class="fas fa-user-circle"></i> Kullanıcı Profilim</h2>
        
        <div style="display: flex; gap: 40px;">
            
            <div style="flex: 1; padding: 20px; border: 1px solid #ddd; border-radius: 8px;">
                <h3 style="margin-bottom: 15px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Hesap Bilgileri</h3>
                <p><strong>Ad Soyad:</strong> <?php echo htmlspecialchars($kullanici_bilgileri['ad_soyad'] ?? 'Bilinmiyor'); ?></p>
                <p><strong>E-posta:</strong> <?php echo htmlspecialchars($kullanici_bilgileri['eposta'] ?? 'Bilinmiyor'); ?></p>
                </div>
            
            <div style="flex: 2; padding: 20px; border: 1px solid #ddd; border-radius: 8px;">
                <h3 style="margin-bottom: 15px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Geçmiş Siparişlerim</h3>
                
                <?php if (!empty($gecmis_siparisler)): ?>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead style="background-color: #f0f0f0;">
                            <tr>
                                <th style="padding: 10px; text-align: left;">Sipariş No</th>
                                <th style="padding: 10px; text-align: left;">Tarih</th>
                                <th style="padding: 10px; text-align: left;">Toplam</th>
                                <th style="padding: 10px; text-align: left;">Durum</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($gecmis_siparisler as $siparis): ?>
                            <tr style="border-bottom: 1px solid #eee;">
                                <td style="padding: 10px;">#<?php echo htmlspecialchars($siparis['id']); ?></td>
                                <td style="padding: 10px;"><?php echo date('d.m.Y', strtotime($siparis['siparis_tarihi'])); ?></td>
                                <td style="padding: 10px; font-weight: bold;"><?php echo number_format($siparis['genel_toplam'], 2, ',', '.') . ' ₺'; ?></td>
                                <td style="padding: 10px; color: #27ae60;">Tamamlandı</td> 
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Henüz tamamlanmış bir siparişiniz bulunmamaktadır.</p>
                <?php endif; ?>
            </div>
        </div>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>