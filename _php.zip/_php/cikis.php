<?php
// Oturumu başlat
session_start();

// Tüm oturum değişkenlerini temizle (isteğe bağlı ama önerilir)
$_SESSION = array();

// Oturumu tamamen yok et
session_destroy();

// Kullanıcıyı ana sayfaya yönlendir
header("Location: index.php");
exit();
?>