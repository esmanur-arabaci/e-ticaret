<?php
// urun_detay.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_baglanti.php';

$urun_detay = null; 
$urun_id = isset($_GET['id']) ? (int)$_GET['id'] : 0; 

// 1. Ürün detaylarını çekme
if ($urun_id > 0) {
    $sorgu = $baglanti->prepare("SELECT id, urun_ad, fiyat, aciklama, resim_url FROM urunler WHERE id = ?");
    $sorgu->bind_param("i", $urun_id); 
    $sorgu->execute();
    $sonuc = $sorgu->get_result();

    if ($sonuc->num_rows == 1) {
        $urun_detay = $sonuc->fetch_assoc();
    }
    $sorgu->close();
}

// 2. Yorumları Çekme
$yorumlar = [];
if ($urun_detay) {
    $sql_yorumlar = "SELECT yorum_yapan_ad, yorum_metni, puan, yorum_tarihi 
                     FROM urun_yorumlar 
                     WHERE urun_id = ? 
                     ORDER BY yorum_tarihi DESC";
    
    $sorgu_yorumlar = $baglanti->prepare($sql_yorumlar);
    $sorgu_yorumlar->bind_param("i", $urun_id);
    $sorgu_yorumlar->execute();
    $sonuc_yorumlar = $sorgu_yorumlar->get_result();
    
    if ($sonuc_yorumlar->num_rows > 0) {
        while($yorum = $sonuc_yorumlar->fetch_assoc()) {
            $yorumlar[] = $yorum;
        }
    }
    $sorgu_yorumlar->close();
}

$baglanti->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $urun_detay ? htmlspecialchars($urun_detay['urun_ad']) : 'Ürün Bulunamadı'; ?> - Arch Aksesuar</title>
    <link rel="stylesheet" href="style/style.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<?php include("includes/header.php"); ?>
    
    <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php">ANA SAYFA</a></li>
                    <li><a href="kolyeler.php">KOLYELER <i class="fa-solid fa-chevron-down"></i></a></li>
                    <li><a href="kupe.php">KÜPELER</a></li>
                    <li><a href="bileklik.php">BİLEKLİKLER</a></li>
                    <li><a href="yuzuk.php">YÜZÜKLER</a></li>
                    <li><a href="saat.php">SAATLER</a></li>
                    <li><a href="sahmeran.php">ŞAHMERAN</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <main class="container" style="padding: 60px 0;">
        <?php if (isset($_SESSION['mesaj'])): ?>
            <p style="color: green; text-align: center; margin-bottom: 20px; font-weight: bold;"><?php echo $_SESSION['mesaj']; ?></p>
            <?php unset($_SESSION['mesaj']); endif; ?>
        
        <?php if ($urun_detay): ?>
            
            <div style="display: flex; gap: 40px; border: 1px solid #eee; padding: 30px; align-items: flex-start;">
                
                <div style="width: 40%;">
                    <img src="<?php echo htmlspecialchars($urun_detay['resim_url']); ?>" alt="<?php echo htmlspecialchars($urun_detay['urun_ad']); ?>" style="width: 100%; height: auto; border-radius: 5px;">
                </div>
                
                <div style="width: 60%;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <h2><?php echo htmlspecialchars($urun_detay['urun_ad']); ?></h2>
                        <a href="urun_duzenle.php?id=<?php echo $urun_id; ?>" style="color: #3498db; text-decoration: none; font-size: 0.9em; border: 1px solid #3498db; padding: 5px 10px; border-radius: 4px;">
                            <i class="fa-solid fa-pen-to-square"></i> Düzenle
                        </a>
                    </div>

                    <p style="font-size: 1.8em; color: var(--color-accent); font-weight: bold; margin-bottom: 20px;">
                        <?php echo number_format($urun_detay['fiyat'], 2, ',', '.') . ' ₺'; ?>
                    </p>
                    
                    <h3>Ürün Açıklaması</h3>
                    <p style="margin-bottom: 30px; line-height: 1.6;"><?php echo nl2br(htmlspecialchars($urun_detay['aciklama'])); ?></p>
                    
                    <form action="sepet.php" method="POST" style="display: flex; gap: 15px; align-items: center;">
                        <input type="hidden" name="action" value="ekle"> 
                        <input type="hidden" name="urun_id" value="<?php echo $urun_id; ?>">
                        
                        <label for="adet" style="font-weight: bold;">Adet:</label>
                        <input type="number" id="adet" name="adet" value="1" min="1" style="width: 70px; padding: 8px; text-align: center; border: 1px solid #ccc; border-radius: 4px;">
                        
                        <button type="submit" style="padding: 12px 25px; background-color: var(--color-accent); color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">
                            <i class="fas fa-cart-plus"></i> Sepete Ekle
                        </button>
                    </form>
                </div>
            </div>
            
            <section class="yorumlar-alani" style="margin-top: 50px; padding: 30px; border: 1px solid #ddd; border-radius: 8px;">
                <h3 style="border-bottom: 2px solid var(--color-accent); padding-bottom: 10px; margin-bottom: 25px;">
                    Müşteri Yorumları (<?php echo count($yorumlar); ?>)
                </h3>

                <div class="yorum-formu" style="margin-bottom: 40px; border: 1px solid #eee; padding: 20px; border-radius: 5px;">
                    <h4 style="margin-top: 0;">Yorum Yapın</h4>
                    <form action="yorum_ekle.php" method="POST">
                        <input type="hidden" name="urun_id" value="<?php echo htmlspecialchars($urun_id); ?>">
                        <div style="margin-bottom: 10px;">
                            <label for="yorum_ad">Adınız:</label>
                            <input type="text" id="yorum_ad" name="yorum_yapan_ad" required 
                                   value="<?php echo htmlspecialchars($_SESSION['ad_soyad'] ?? ''); ?>"
                                   style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                        </div>
                        <div style="margin-bottom: 15px;">
                            <label for="puan">Puanınız (1-5):</label>
                            <select id="puan" name="puan" style="padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                                <option value="5">5 Yıldız (Mükemmel)</option>
                                <option value="4">4 Yıldız (İyi)</option>
                                <option value="3">3 Yıldız (Orta)</option>
                                <option value="2">2 Yıldız (Kötü)</option>
                                <option value="1">1 Yıldız (Çok Kötü)</option>
                            </select>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <label for="yorum_metni">Yorumunuz:</label>
                            <textarea id="yorum_metni" name="yorum_metni" rows="4" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;"></textarea>
                        </div>
                        <button type="submit" style="padding: 10px 20px; background-color: var(--color-accent); color: white; border: none; border-radius: 4px; cursor: pointer;">Yorumu Gönder</button>
                    </form>
                </div>
                
                <?php if (!empty($yorumlar)): ?>
                    <?php foreach ($yorumlar as $yorum): ?>
                        <div class="tek-yorum" style="border-bottom: 1px dashed #eee; padding-bottom: 15px; margin-bottom: 15px;">
                            <p style="margin: 0; font-weight: bold;">
                                <?php echo htmlspecialchars($yorum['yorum_yapan_ad']); ?>
                                <span style="font-size: 0.8em; color: #777; font-weight: normal; margin-left: 10px;">
                                    - <?php echo date('d.m.Y H:i', strtotime($yorum['yorum_tarihi'])); ?>
                                </span>
                            </p>
                            <div class="puanlama" style="color: #f39c12; font-size: 1.1em; margin: 5px 0;">
                                <?php 
                                    $puan = (int)$yorum['puan'];
                                    for ($i = 0; $i < 5; $i++) {
                                        echo '<i class="fas fa-star' . ($i < $puan ? '' : '-o') . '"></i>';
                                    }
                                ?>
                            </div>
                            <p style="margin: 5px 0 0;"><?php echo nl2br(htmlspecialchars($yorum['yorum_metni'])); ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Bu ürün için henüz yorum yapılmamıştır. İlk yorumu siz yapın!</p>
                <?php endif; ?>
            </section>

        <?php else: ?>
            <h2 style="text-align: center;">Hata: İstenen ürün bulunamadı.</h2>
        <?php endif; ?>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>