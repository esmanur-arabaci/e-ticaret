<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

include 'db_baglanti.php';

// Sepet oturumda yoksa boş bir dizi olarak tanımla
$sepet = isset($_SESSION['sepet']) ? $_SESSION['sepet'] : [];
$genel_toplam = 0;
$sepet_urunleri = [];

// 1. SEPET İŞLEM YÖNETİMİ (POST ve GET)


// --- POST İŞLEMLERİ (Ekleme, Güncelleme) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    
    $urun_id = isset($_POST['urun_id']) ? (int)$_POST['urun_id'] : 0;
    $action = $_POST['action'];
    
    if ($urun_id > 0) {
        
        // Sepete Yeni Ürün Ekleme (urun_detay.php'den gelir)
        if ($action == 'ekle') {
            $adet = isset($_POST['adet']) ? (int)$_POST['adet'] : 1;
            
            if (array_key_exists($urun_id, $sepet)) {
                $sepet[$urun_id] += $adet; // Adeti artır
            } else {
                $sepet[$urun_id] = $adet;  // Yeni ürünü ekle
            }
            $_SESSION['mesaj'] = "Ürün sepete başarıyla eklendi!";
        } 
        
        // Sepet Adeti Güncelleme (Sepet sayfasından gelir)
        elseif ($action == 'guncelle') {
            $yeni_adet = (int)$_POST['adet'];
            
            if ($yeni_adet > 0) {
                $sepet[$urun_id] = $yeni_adet;
                $_SESSION['mesaj'] = "Sepet güncellendi.";
            } else {
                unset($sepet[$urun_id]); // Adet 0 ise ürünü sil
                $_SESSION['mesaj'] = "Ürün sepetten çıkarıldı.";
            }
        }
    }
    
    $_SESSION['sepet'] = $sepet; // Güncel sepeti oturuma kaydet (KRİTİK)
    header('Location: sepet.php'); 
    exit();
}

// --- GET İŞLEMLERİ (Silme - Link ile gelir) ---
if (isset($_GET['action']) && $_GET['action'] == 'sil' && isset($_GET['id'])) {
    $urun_id_sil = (int)$_GET['id'];
    
    if (isset($sepet[$urun_id_sil])) {
        unset($sepet[$urun_id_sil]);
        $_SESSION['sepet'] = $sepet;
        $_SESSION['mesaj'] = "Ürün sepetten silindi.";
    }
    header('Location: sepet.php');
    exit();
}


// 2. SEPET İÇERİĞİNİ VERİ TABANINDAN ÇEKME VE HESAPLAMA


$sepet_urun_idleri = empty($sepet) ? [0] : array_keys($sepet); 

if (!empty($sepet)) {
    $id_listesi = implode(',', $sepet_urun_idleri);
    
    // SQL Sorgusu: Tüm ürünleri tek sorguyla çek
    $sql = "SELECT id, urun_ad, fiyat, resim_url FROM urunler WHERE id IN ($id_listesi)";
    $sonuc = $baglanti->query($sql);

    if ($sonuc) {
        while ($urun = $sonuc->fetch_assoc()) {
            $urun_id = $urun['id'];
            $adet = $sepet[$urun_id]; // Sepetteki adeti al
            $tekil_toplam = $urun['fiyat'] * $adet;
            $genel_toplam += $tekil_toplam; // Genel toplamı artır

            // Ürünü, adet ve toplam bilgisiyle birlikte dizide tut
            $sepet_urunleri[$urun_id] = [
                'detay' => $urun,
                'adet' => $adet,
                'tekil_toplam' => $tekil_toplam
            ];
        }
    }
    $baglanti->close();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sepetim - Arch Aksesuar</title>
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<?php include("includes/header.php"); ?>

       <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php" >ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" >KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php" >YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    <main class="container" style="padding: 60px 0;">
        <h2 style="text-align: center; color: var(--color-accent); margin-bottom: 40px;">Alışveriş Sepetim</h2>

        <?php 
        // Session mesajını göster (sepete ekleme, silme, güncelleme)
        if (isset($_SESSION['mesaj'])): ?>
            <p style="text-align: center; color: green; font-weight: bold; margin-bottom: 20px;"><?php echo $_SESSION['mesaj']; ?></p>
            <?php unset($_SESSION['mesaj']); 
        endif; ?>

        <table style="width: 100%; border-collapse: collapse; background-color: var(--color-light-bg); box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden;">
            <thead style="background-color: var(--color-menu-bg); color: var(--color-text-light);">
                <tr>
                    <th style="padding: 15px;">Ürün</th>
                    <th style="padding: 15px;">Adet</th>
                    <th style="padding: 15px;">Fiyat</th>
                    <th style="padding: 15px;">Toplam</th>
                    <th style="padding: 15px;">İşlem</th>
                </tr>
            </thead>
            <tbody>
                
                <?php if (!empty($sepet_urunleri)): ?>
                    <?php foreach ($sepet_urunleri as $urun_id => $urun_bilgisi): ?>
                    <tr style="text-align: center; border-bottom: 1px solid #ccc;">
<td style="padding: 15px;">
    <div style="display: flex; 
                align-items: center; 
                justify-content: flex-start; /* Sola hizala */
                gap: 10px;
                /* İçeriği tablonun ortasına itmemek için */
                width: 100%;"> 
        
        <img src="<?php echo htmlspecialchars($urun_bilgisi['detay']['resim_url']); ?>" 
             alt="<?php echo htmlspecialchars($urun_bilgisi['detay']['urun_ad']); ?>" 
             style="width: 60px; height: 60px; object-fit: cover; border-radius: 5px;">
        
        <span><?php echo htmlspecialchars($urun_bilgisi['detay']['urun_ad']); ?></span>
    </div>
</td>
                        <td style="padding: 15px;">
                            <form action="sepet.php" method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="guncelle">
                                <input type="hidden" name="urun_id" value="<?php echo $urun_id; ?>">
                                <input type="number" name="adet" value="<?php echo $urun_bilgisi['adet']; ?>" min="0" 
                                       onchange="this.form.submit()" 
                                       style="width: 60px; padding: 5px; text-align: center;">
                            </form>
                        </td>
                        <td style="padding: 15px;"><?php echo number_format($urun_bilgisi['detay']['fiyat'], 2, ',', '.') . ' ₺'; ?></td>
                        <td style="padding: 15px;"><?php echo number_format($urun_bilgisi['tekil_toplam'], 2, ',', '.') . ' ₺'; ?></td>
                        <td style="padding: 15px;">
                            <a href="sepet.php?action=sil&id=<?php echo $urun_id; ?>">
                                <button style="background-color: #c0392b; color: white; border: none; padding: 6px 10px; border-radius: 5px; cursor: pointer;">Sil</button>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr style="text-align: center;"><td colspan="5" style="padding: 30px;">Sepetinizde henüz ürün bulunmamaktadır.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div style="
            margin-top: 30px;
            display: flex;
            justify-content: flex-end;
            flex-direction: column;
            align-items: flex-end;
            gap: 15px;
        ">
            <p style="font-size: 1.2em; color: var(--color-accent); font-weight: bold;">Ara Toplam: <?php echo number_format($genel_toplam, 2, ',', '.') . ' ₺'; ?></p>
            <p style="font-size: 1.3em; font-weight: bold; color: var(--color-text-dark);">Genel Toplam: <?php echo number_format($genel_toplam, 2, ',', '.') . ' ₺'; ?></p>
            
            <?php if (!empty($sepet_urunleri)): ?>
            <a href="odeme.php" style="
                background-color: var(--color-accent);
                color: var(--color-text-light);
                padding: 10px 25px;
                border-radius: 5px;
                font-weight: bold;
                text-decoration: none;
                transition: background-color 0.3s;
            ">Ödeme Sayfasına Geç</a>
            <?php endif; ?>
        </div>
    </main>
<?php include("includes/footer.php"); ?>
</body>
</html>
