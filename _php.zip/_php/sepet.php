<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sepetim - Arch Aksesuar</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
<?php include("includes/header.php"); ?>
    
    <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php" >ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" >KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php" >YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    <!-- =================== SEPET İÇERİĞİ =================== -->
    <main class="container" style="padding: 60px 0;">
        <h2 style="text-align: center; color: var(--color-accent); margin-bottom: 40px;">Alışveriş Sepetim</h2>

        <!-- Sepet Tablosu -->
        <table style="width: 100%; border-collapse: collapse; background-color: var(--color-light-bg); box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden;">
            <thead style="background-color: var(--color-menu-bg); color: var(--color-text-light);">
                <tr>
                    <th style="padding: 15px;">Ürün</th>
                    <th style="padding: 15px;">Adet</th>
                    <th style="padding: 15px;">Fiyat</th>
                    <th style="padding: 15px;">Toplam</th>
                    <th style="padding: 15px;">İşlem</th>
                </tr>
            </thead>
            <tbody>
                <!-- Ürün 1 -->
                <tr style="text-align: center; border-bottom: 1px solid #ccc;">
                    <td style="padding: 15px; display: flex; align-items: center; justify-content: center; gap: 10px;">
                        <img src="images/urun1.jpg" alt="Ürün 1" style="width: 60px; height: 60px; object-fit: cover; border-radius: 5px;">
                        <span>Gümüş Kolye</span>
                    </td>
                    <td style="padding: 15px;">
                        <input type="number" value="1" min="1" style="width: 60px; padding: 5px; text-align: center;">
                    </td>
                    <td style="padding: 15px;">250 ₺</td>
                    <td style="padding: 15px;">250 ₺</td>
                    <td style="padding: 15px;">
                        <button style="background-color: #c0392b; color: white; border: none; padding: 6px 10px; border-radius: 5px; cursor: pointer;">Sil</button>
                    </td>
                </tr>

                <!-- Ürün 2 -->
                <tr style="text-align: center;">
                    <td style="padding: 15px; display: flex; align-items: center; justify-content: center; gap: 10px;">
                        <img src="images/urun2.jpg" alt="Ürün 2" style="width: 60px; height: 60px; object-fit: cover; border-radius: 5px;">
                        <span>Taşlı Küpe</span>
                    </td>
                    <td style="padding: 15px;">
                        <input type="number" value="2" min="1" style="width: 60px; padding: 5px; text-align: center;">
                    </td>
                    <td style="padding: 15px;">180 ₺</td>
                    <td style="padding: 15px;">360 ₺</td>
                    <td style="padding: 15px;">
                        <button style="background-color: #c0392b; color: white; border: none; padding: 6px 10px; border-radius: 5px; cursor: pointer;">Sil</button>
                    </td>
                </tr>
            </tbody>
        </table>

        <!-- Toplam Bilgisi -->
        <div style="
            margin-top: 30px;
            display: flex;
            justify-content: flex-end;
            flex-direction: column;
            align-items: flex-end;
            gap: 15px;
        ">
            <p style="font-size: 1.2em; color: var(--color-accent); font-weight: bold;">Ara Toplam: 610 ₺</p>
            <p style="font-size: 1.3em; font-weight: bold; color: var(--color-text-dark);">Genel Toplam: 610 ₺</p>
            <a href="odeme.html" style="
                background-color: var(--color-accent);
                color: var(--color-text-light);
                padding: 10px 25px;
                border-radius: 5px;
                font-weight: bold;
                text-decoration: none;
                transition: background-color 0.3s;
            ">Ödeme Sayfasına Geç</a>
        </div>
    </main>
<?php include("includes/footer.php"); ?>
</body>
</html>
