<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arch Aksesuar | Şıklığın ve Estetiğin Buluşma Noktası</title>
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<?php include("includes/header.php"); ?>
        <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php">ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php" >KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" class="active">KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php">YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    
    <main>
        <div class="container">
            
                <div class="product-grid">
                    
 <div class="product-card">
    <img src="images/küpe.images/kg1.webp" alt="Dört Tırnaklı Zirkon        1 Küpe" class="product-img">
    <div class="product-info">
        <h4>Dört Tırnaklı Zirkon Küpe</h4>
        <p>119.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg2.webp" alt="Minimal Tektaş Küpe" class="product-img">
    <div class="product-info">
        <h4>Minimal Tektaş Küpe</h4>
        <p>159.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg3.webp" alt="Sade Top Küpe Seti" class="product-img">
    <div class="product-info">
        <h4>Sade Top Küpe Seti</h4>
        <p>125.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg4.webp" alt="Yeşil Taşlı Yılan Küpe" class="product-img">
    <div class="product-info">
        <h4>Yeşil Taşlı Yılan Küpe</h4>
        <p>175.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg5.webp" alt="Bisiklet Figürlü Halka Küpe" class="product-img">
    <div class="product-info">
        <h4>Bisiklet Figürlü Halka Küpe</h4>
        <p>140.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg6.webp" alt="Taşlı Fiyonk Sarkıt Küpe" class="product-img">
    <div class="product-info">
        <h4>Taşlı Fiyonk Sarkıt Küpe</h4>
        <p>195.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg10.webp" alt="Taşlı Mini Sallantılı Halka Küpe" class="product-img">
    <div class="product-info">
        <h4>Taşlı Mini Sallantılı Halka Küpe</h4>
        <p>150.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg11.webp" alt="Sedefli Kaplumbağa Küpe" class="product-img">
    <div class="product-info">
        <h4>Sedefli Kaplumbağa Küpe</h4>
        <p>135.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg12.webp" alt="Uzun Zirkon Tırmanıcı Küpe" class="product-img">
    <div class="product-info">
        <h4>Uzun Zirkon Tırmanıcı Küpe</h4>
        <p>210.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg13.webp" alt="Minimalist Taşlı Earcuff Küpe" class="product-img">
    <div class="product-info">
        <h4>Minimalist Taşlı Earcuff Küpe</h4>
        <p>105.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg14.webp" alt="Taşlı Mini Kıkırdak Küpesi" class="product-img">
    <div class="product-info">
        <h4>Taşlı Mini Kıkırdak Küpesi</h4>
        <p>145.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg15.webp" alt="Yıldız Formlu Stud Küpe Seti" class="product-img">
    <div class="product-info">
        <h4>Yıldız Formlu Küpe</h4>
        <p>130.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg16.webp" alt="Taşlı Güneş ve Hilal Halka Küpe" class="product-img">
    <div class="product-info">
        <h4>Taşlı Güneş ve Hilal Halka Küpe</h4>
        <p>160.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg17.webp" alt="Kıvrımlı Taş Detaylı Uzun Küpe" class="product-img">
    <div class="product-info">
        <h4>Kıvrımlı Taş Detaylı Uzun Küpe</h4>
        <p>190.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kg18.webp" alt="Baget Taşlı Mini Stud Küpe" class="product-img">
    <div class="product-info">
        <h4>Baget Taşlı Mini Stud Küpe</h4>
        <p>180.0₺</p>
    </div>
</div>
                    
                    </div>
            </section>
        </div>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>