<?php
session_start(); 
include 'db_baglanti.php'; 

$sql = "SELECT id, urun_ad, aciklama, fiyat, resim_url FROM urunler WHERE kategori = 'kupe_gumus'";

$sonuc = $baglanti->query($sql);

$urunler = []; 
if ($sonuc && $sonuc->num_rows > 0) {
    while($satir = $sonuc->fetch_assoc()) {
        $urunler[] = $satir;
    }
}
$baglanti->close();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arch Aksesuar | Şıklığın ve Estetiğin Buluşma Noktası</title>
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<?php include("includes/header.php"); ?>
        <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php">ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php" >KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" class="active">KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php">YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    
    <main>
        <div class="container">
            
                <div class="product-grid">
                    
 <div class="product-card">
<main>
    <div class="container">
        <section class="product-gallery">
            <h2>GÜMÜŞ KÜPE KOLEKSİYONU</h2> 

            <div class="product-grid">
                
                <?php 

                if (!empty($urunler)) {
                    foreach ($urunler as $urun) {
                        $detay_linki = "urun_detay.php?id=" . htmlspecialchars($urun['id']);
                    ?>
                    
                    <a href="<?php echo $detay_linki; ?>" class="product-card-link"> 
                        <div class="product-card">
                            
                            <img src="<?php echo htmlspecialchars($urun['resim_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($urun['urun_ad']); ?>" 
                                 class="product-img">
                            
                            <div class="product-info">
                                <h4><?php echo htmlspecialchars($urun['urun_ad']); ?></h4>
                                
                                <p><?php echo number_format($urun['fiyat'], 2, ',', '.') . ' ₺'; ?></p>
                                
                            </div>
                        </div>
                    </a>
                    <?php
                    } 
                } else {
                    echo '<p style="grid-column: 1 / -1; text-align: center;">Bu kategoride henüz gümüş küpe bulunmamaktadır.</p>';
                }
                ?>
            </div>
        </section>
    </div>
</main>
                    </div>
            </section>
        </div>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>