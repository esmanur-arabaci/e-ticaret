<?php
$host = 'localhost'; 
$kullanici = 'root';
$sifre = 'esma_nur22';
$vt_adi = '_php';

$baglanti = new mysqli($host, $kullanici, $sifre, $vt_adi);

if ($baglanti->connect_error) {
    die("Veri Tabanı Bağlantı Hatası: " . $baglanti->connect_error);
}

$baglanti->set_charset("utf8mb4");
?>

