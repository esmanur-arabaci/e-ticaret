<?php
session_start(); 
include 'db_baglanti.php'; 

// 1. Kullanıcı Giriş Kontrolü
if (!isset($_SESSION['oturum_basarili']) || $_SESSION['oturum_basarili'] !== true) {
    $_SESSION['login_hata'] = "Ödeme işlemine devam etmek için lütfen giriş yapın.";
    header('Location: giris.php');
    exit();
}

// 2. Sepet Kontrolü (Sepet boşsa yönlendir)
if (!isset($_SESSION['sepet']) || empty($_SESSION['sepet'])) {
    $_SESSION['mesaj'] = "Ödeme işlemine devam etmek için sepetinizde ürün bulunmalıdır.";
    header('Location: sepet.php');
    exit();
}

// --- VERİ ÇEKME VE TOPLAM HESAPLAMA ---
$sepet = $_SESSION['sepet'];
$genel_toplam = 0;

$id_listesi = implode(',', array_keys($sepet));
// urunler tablosundan fiyatları çekiyoruz
$sql = "SELECT id, fiyat FROM urunler WHERE id IN ($id_listesi)";
$sonuc = $baglanti->query($sql);

if ($sonuc) {
    while ($urun = $sonuc->fetch_assoc()) {
        $urun_id = $urun['id'];
        $adet = $sepet[$urun_id];
        // Genel toplamı hesapla
        $genel_toplam += $urun['fiyat'] * $adet;
    }
}
$baglanti->close(); // Bağlantıyı kapattık

// Hata mesajını session'dan çek (varsa)
$hata_mesaji = $_SESSION['mesaj'] ?? '';
if ($hata_mesaji) {
    unset($_SESSION['mesaj']);
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ödeme Yap - Arch Aksesuar</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
<?php include("includes/header.php"); ?>
    
    <main class="container" style="padding: 60px 0;">
        <?php if ($hata_mesaji): ?>
            <div style="text-align: center; color: red; margin-bottom: 20px; font-weight: bold;"><?php echo $hata_mesaji; ?></div>
        <?php endif; ?>

        <h2 style="text-align: center; color: var(--color-accent); margin-bottom: 40px;">Ödeme Bilgileri</h2>

        <div style="text-align: right; margin-bottom: 20px;">
            <p style="font-size: 1.5em; font-weight: bold; color: #c0392b;">
                Ödenecek Toplam: <?php echo number_format($genel_toplam, 2, ',', '.') . ' ₺'; ?>
            </p>
        </div>

        <form action="onay.php" method="POST" style="display: flex; gap: 30px; background-color: #f8f8f8; padding: 30px; border-radius: 8px;">
            
            <div style="flex: 1; border-right: 1px solid #ddd; padding-right: 30px;">
                <h3 style="color: var(--color-text-dark); margin-bottom: 20px;">1. Teslimat ve Fatura Adresi</h3>
                
                <div style="margin-bottom: 15px;">
                    <label for="ad_soyad">Ad Soyad</label>
                    <input type="text" id="ad_soyad" name="ad_soyad" required style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px;" value="<?php echo htmlspecialchars($_SESSION['ad_soyad'] ?? ''); ?>">
                </div>

                <div style="margin-bottom: 15px;">
                    <label for="adres">Adres (Cadde, Sokak, No)</label>
                    <textarea id="adres" name="adres" required style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px;"></textarea>
                </div>

                <div style="margin-bottom: 15px;">
                    <label for="il">Şehir / İl</label>
                    <input type="text" id="il" name="il" required style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px;">
                </div>

                <div style="margin-bottom: 15px;">
                    <label for="telefon">Telefon Numarası</label>
                    <input type="tel" id="telefon" name="telefon" required style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 4px;">
                </div>
            </div>

            <div style="flex: 1;">
                <h3 style="color: var(--color-text-dark); margin-bottom: 20px;">2. Ödeme Yöntemi</h3>
                
                <div style="margin-bottom: 25px;">
                    <input type="radio" id="kart" name="odeme_yontemi" value="kart" required checked>
                    <label for="kart" style="font-weight: bold;">Kredi/Banka Kartı</label><br>
                    
                    <input type="radio" id="kapida" name="odeme_yontemi" value="kapida">
                    <label for="kapida" style="font-weight: bold;">Kapıda Ödeme</label>
                </div>

                <div id="kart_bilgileri" style="border: 1px solid #eee; padding: 15px; background-color: white; border-radius: 4px;">
                    <p style="font-weight: bold; margin-bottom: 10px;">Kart Bilgileri (Simülasyon)</p>
                    <div style="margin-bottom: 10px;">
                        <input type="text" placeholder="Kart Numarası" name="kart_no" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <input type="text" placeholder="MM/YY" name="kart_tarih" style="width: 50%; padding: 8px; border: 1px solid #ccc; border-radius: 3px;">
                        <input type="text" placeholder="CVV" name="kart_cvv" style="width: 50%; padding: 8px; border: 1px solid #ccc; border-radius: 3px;">
                    </div>
                </div>

                <input type="hidden" name="genel_toplam" value="<?php echo $genel_toplam; ?>">
                
                <button type="submit" style="
                    width: 100%; 
                    padding: 15px; 
                    background-color: #27ae60; 
                    color: white; 
                    border: none; 
                    border-radius: 5px; 
                    font-size: 1.1em; 
                    font-weight: bold; 
                    margin-top: 30px;
                    cursor: pointer;
                ">Siparişi Tamamla</button>
            </div>
        </form>
    </main>
<?php include("includes/footer.php"); ?>
</body>
</html>