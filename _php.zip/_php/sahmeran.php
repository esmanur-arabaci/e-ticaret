<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARCH AKSESUAR - YÜZÜK KOLEKSİYONU</title>
    <link rel="stylesheet" href="style/style.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<?php include("includes/header.php"); ?>
    
    <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php" >ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" >KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php" >YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php" class="active"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    <main>
        <div class="container">
            

                <div class="product-grid">
                    
<div class="product-card">
    <img src="images/şahmeran.images/s1" alt="Gümüş İnce Zincir Dört Taşlı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Gümüş İnce Dört Taşlı Şahmeran</h4>
        <p>135.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/şahmeran.images/s2" alt="Gümüş Zincir Sallantılı Taş Detaylı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Sallantılı Taşlı Gümüş Şahmeran</h4>
        <p>180.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/şahmeran.images/s3" alt="Altın İnce Zincir Y Damla Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Altın Y Damla Zincir Şahmeran</h4>
        <p>150.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/şahmeran.images/s4" alt="Altın İnce Zincir Taşlı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Altın İnce Taşlı Şahmeran</h4>
        <p>175.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/şahmeran.images/s5" alt="Gümüş İnce Zincir Taş Detaylı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Gümüş İnce Taş Detaylı Şahmeran</h4>
        <p>160.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/şahmeran.images/s6" alt="Altın Y Damla Tek Taşlı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Altın Y Damla Tek Taşlı Şahmeran</h4>
        <p>165.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/şahmeran.images/s7" alt="Altın Zincir İnce Taşlı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Altın Zincir İnce Taşlı Şahmeran</h4>
        <p>165.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/şahmeran.images/s8" alt="Gümüş Zincir İnce Taşlı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Gümüş Zincir İnce Taşlı Şahmeran</h4>
        <p>165.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/şahmeran.images/s9" alt="Altın Zincir Taşlı Sallantılı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Altın Zincir Taşlı Sallantılı Şahmeran</h4>
        <p>175.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/şahmeran.images/s10" alt="Altın Zincir Çoklu Taşlı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Gümüş Zincir Çoklu Taşlı Şahmeran</h4>
        <p>190.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/şahmeran.images/s11" alt="Altın Zincir Renkli Kare Taşlı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Altın Zincir Renkli Kare Şahmeran</h4>
        <p>210.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/şahmeran.images/s12" alt="Gümüş Zincir Renkli Sıralı Taşlı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Gümüş Zincir Renkli Sıralı Şahmeran</h4>
        <p>200.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/şahmeran.images/s13" alt="Altın Zincir Sıralı Taşlı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Altın Zincir Sıralı Taşlı Şahmeran</h4>
        <p>210.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/şahmeran.images/s14" alt="Altın Zincir Tek Taşlı Damla Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Altın Zincir Tek Taşlı Damla Şahmeran</h4>
        <p>180.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/şahmeran.images/s15" alt="Altın Zincir Çoklu İnce Katmanlı Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Altın Zincir Çoklu Katmanlı Şahmeran</h4>
        <p>230.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/şahmeran.images/s16" alt="Gümüş Zincir İnce Sade Şahmeran" class="product-img">
    <div class="product-info">
        <h4>Gümüş Zincir İnce Sade Şahmeran</h4>
        <p>150.0₺</p>
    </div>
</div>

                    </div>
            </section>
        </div>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>