<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARCH AKSESUAR - BİLEKLİK KOLEKSİYONU</title>
    <link rel="stylesheet" href="style/style.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<?php include("includes/header.php"); ?>
    
    <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php" >ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" >KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php" class="active">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php">YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    
    <main>
        <div class="container">
            

                <div class="product-grid">
                    
                   <div class="product-card">
    <img src="images/bileklik.images/bç1" alt="Kalın Burgu Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>Kalın Burgu Zincir Bileklik</h4>
        <p>135.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç2" alt="Minimal İnce Yassı Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>İnce Yassı Zincir Bileklik</h4>
        <p>89.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç3" alt="Taş Detaylı İnce Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>Taş Detaylı İnce Bileklik</h4>
        <p>165.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç4" alt="Örgü Desenli Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>Örgü Desenli Zincir Bileklik</h4>
        <p>110.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç5" alt="Tek Sıra Kalın Bağlantılı Bileklik" class="product-img">
    <div class="product-info">
        <h4>Tek Sıra Kalın Bileklik</h4>
        <p>180.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç6" alt="Dalgalı İnce Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>Dalgalı İnce Zincir Bileklik</h4>
        <p>65.0₺</p>
    </div>
</div>


<div class="product-card">
    <img src="images/bileklik.images/bç11" alt="Kalın Kalp Bağlantılı Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>Kalın Kalp Bağlantılı Bileklik</h4>
        <p>135.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç12" alt="Çubuk Bağlantılı İnce Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>Çubuk Bağlantılı İnce Bileklik</h4>
        <p>89.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç13" alt="Taş Detaylı Karma Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>Taş Detaylı Karma Zincir Bileklik</h4>
        <p>165.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç14" alt="Örgü Tip İnce Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>Örgü Tip İnce Zincir Bileklik</h4>
        <p>110.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç15" alt="Üç Renkli İnce Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>Üç Renkli İnce Zincir Bileklik</h4>
        <p>180.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç24" alt="İnce Pul Detaylı Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>İnce Pul Detaylı Zincir Bileklik</h4>
        <p>65.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç17" alt="Taşlı Minimal İnce Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>Taşlı Minimal İnce Bileklik</h4>
        <p>65.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç18" alt="Yuvarlak Bağlantılı İnce Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>Yuvarlak Bağlantılı İnce Bileklik</h4>
        <p>65.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/bileklik.images/bç23" alt="Taşlı İnce Dalgalı Zincir Bileklik" class="product-img">
    <div class="product-info">
        <h4>Taşlı İnce Dalgalı Zincir Bileklik</h4>
        <p>165.0₺</p>
    </div>
</div>

                    </div>
            </section>
        </div>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>