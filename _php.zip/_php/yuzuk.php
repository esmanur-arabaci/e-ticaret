<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARCH AKSESUAR - YÜZÜK KOLEKSİYONU</title>
    <link rel="stylesheet" href="style/style.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<?php include("includes/header.php"); ?>
    
    <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php" >ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" >KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php" class="active">YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    <main>
        <div class="container">
            
            <section class="hero-section">
                <img src="images/yüzük.images/yy1" alt="Yüzük Koleksiyonu Vitrin Görseli" class="hero-image"> 
            </section>

            <section class="product-gallery">
                <h2>ÖZEL YÜZÜK TASARIMLARI</h2> 

                <div class="product-grid">
                    
<div class="product-card">
    <img src="images/yüzük.images/y1" alt="İnce Taşlı Sarmal Ayarlanabilir Yüzük" class="product-img">
    <div class="product-info">
        <h4>İnce Taşlı Sarmal Yüzük</h4>
        <p>130.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/yüzük.images/y2" alt="Mavi Yıldız Charm'lı Ayarlanabilir Yüzük" class="product-img">
    <div class="product-info">
        <h4>Mavi Yıldız Charm Yüzük</h4>
        <p>150.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/yüzük.images/y3" alt="Çift Bantlı Taş Detaylı Yüzük" class="product-img">
        <div class="product-info">
        <h4>Çift Bantlı Taşlı Yüzük</h4>
        <p>145.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/yüzük.images/y4" alt="Taşlı Çubuk Detaylı Ayarlanabilir Yüzük" class="product-img">
    <div class="product-info">
        <h4>Taşlı Çubuk Yüzük</h4>
        <p>165.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/yüzük.images/y5" alt="Taşlı İnce Bant Yüzük" class="product-img">
    <div class="product-info">
        <h4>Taşlı İnce Bant Yüzük</h4>
        <p>175.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/yüzük.images/y6" alt="Dalgalı Tasarım Kalın Yüzük" class="product-img">
    <div class="product-info">
        <h4>Dalgalı Tasarım Kalın Yüzük</h4>
        <p>155.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/yüzük.images/y7" alt="Taşlı İnce Sarmal Yüzük" class="product-img">
    <div class="product-info">
        <h4>Taşlı İnce Sarmal Yüzük</h4>
        <p>140.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/y8" alt="Taşlı ve Dalgalı Çevre Yüzük" class="product-img">
    <div class="product-info">
        <h4>Taşlı Dalgalı Çevre Yüzük</h4>
        <p>160.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/y9" alt="Düzensiz Kalın Bant Yüzük" class="product-img">
    <div class="product-info">
        <h4>Düzensiz Kalın Bant Yüzük</h4>
        <p>135.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/y10" alt="Taşlı Halka Yüzük" class="product-img">
    <div class="product-info">
        <h4>Taşlı Halka Yüzük</h4>
        <p>140.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/y11" alt="Renkli Taşlı Çiçek Motifli Yüzük" class="product-img">
    <div class="product-info">
        <h4>Renkli Taşlı Çiçek Yüzük</h4>
        <p>185.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/y12" alt="Taşlı Minik Çiçek Yüzük" class="product-img">
    <div class="product-info">
        <h4>Taşlı Minik Çiçek Yüzük</h4>
        <p>170.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/yüzük.images/y13" alt="Yeşil Göz Motifli Taşlı Yüzük" class="product-img">
    <div class="product-info">
        <h4>Yeşil Göz Motifli Yüzük</h4>
        <p>190.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/y14" alt="Göz Desenli Renkli Taşlı Yüzük" class="product-img">
    <div class="product-info">
        <h4>Göz Desenli Renkli Yüzük</h4>
        <p>200.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/y15" alt="Büyük Köşeli Zirkon Taşlı Yüzük" class="product-img">
    <div class="product-info">
        <h4>Büyük Köşeli Zirkon Yüzük</h4>
        <p>220.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/y16" alt="Renkli Taşlı Halka Yüzük" class="product-img">
    <div class="product-info">
        <h4>Renkli Taşlı Halka Yüzük</h4>
        <p>160.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/y17" alt="Tamamen Taşlı Minik Çiçek Yüzük" class="product-img">
    <div class="product-info">
        <h4>Tamamen Taşlı Minik Çiçek</h4>
        <p>180.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/y18" alt="Kelebek Motifli İnce Yüzük" class="product-img">
    <div class="product-info">
        <h4>Kelebek Motifli İnce Yüzük</h4>
        <p>145.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/y19" alt="Tek Zirkon Taşlı Burgu Yüzük" class="product-img">
    <div class="product-info">
        <h4>Tek Zirkon Taşlı Burgu Yüzük</h4>
        <p>170.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/y20" alt="Taşlı V Formlu Yüzük" class="product-img">
    <div class="product-info">
        <h4>Taşlı V Formlu Yüzük</h4>
        <p>155.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/yüzük.images/y21" alt="Taşlı Çiçek Ortası Kalın Yüzük" class="product-img">
    <div class="product-info">
        <h4>Taşlı Çiçek Ortası Kalın Yüzük</h4>
        <p>195.0₺</p>
    </div>
</div>


<div class="product-card">
    <img src="images/yüzük.images/yg1" alt="Gümüş Üçlü Kalp Formlu Yüzük Seti" class="product-img">
    <div class="product-info">
        <h4>Gümüş Üçlü Kalp Yüzük Seti</h4>
        <p>150.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/yg2" alt="Gümüş Minimalist Dalgalı Yüzük" class="product-img">
    <div class="product-info">
        <h4>Gümüş Minimalist Dalgalı Yüzük</h4>
        <p>110.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/yüzük.images/yg3" alt="Gümüş Baget Taşlı İnce Yüzük" class="product-img">
    <div class="product-info">
        <h4>Gümüş Baget Taşlı İnce Yüzük</h4>
        <p>135.0₺</p>
    </div>
</div>

                    </div>
            </section>
        </div>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>