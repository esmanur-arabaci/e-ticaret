<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arch Aksesuar | Şıklığın ve Estetiğin Buluşma Noktası</title>
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<?php include("includes/header.php"); ?>
        <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php">ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php" class="active">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" >KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php">YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    
    <main>
        <div class="container">
            
                <div class="product-grid">
                    
<div class="product-card">
    <img src="images/kolye.images/kkl10.jpg" alt="Kristal Yıldız Kolye" class="product-img">
    <div class="product-info">
        <h4>Kristal Yıldız Kolye</h4>
        <p>1450 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl9.jpg" alt="İnci Işıltısı Kolye" class="product-img">
    <div class="product-info">
        <h4>İnci Işıltısı Kolye</h4>
        <p>1100 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl8.jpg" alt="Gold Bağlantı Zincir Kolye" class="product-img">
    <div class="product-info">
        <h4>Gold Bağlantı Zincir Kolye</h4>
        <p>950 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl7.webp" alt="Parlayan Yıldız Kolye" class="product-img">
    <div class="product-info">
        <h4>Parlayan Yıldız Kolye</h4>
        <p>1650 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl6.webp" alt="Zarif Zincir Kolye" class="product-img">
    <div class="product-info">
        <h4>Zarif Zincir Kolye</h4>
        <p>890 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl5.webp" alt="Minimal Taşlı Kolye" class="product-img">
    <div class="product-info">
        <h4>Minimal Taşlı Kolye</h4>
        <p>1290 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl4.webp" alt="Göz Boncuklu Plaka Kolye" class="product-img">
    <div class="product-info">
        <h4>Göz Boncuklu Plaka Kolye</h4>
        <p>1450 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl3.webp" alt="İkili İnci Kolye" class="product-img">
    <div class="product-info">
        <h4>İkili İnci Kolye</h4>
        <p>1100 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl2.webp" alt="Kalın Halka Zincir Kolye" class="product-img">
    <div class="product-info">
        <h4>Kalın Halka Zincir Kolye</h4>
        <p>950 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl1.webp" alt="Çiçek Motifli Kolye" class="product-img">
    <div class="product-info">
        <h4>Çiçek Motifli Kolye</h4>
        <p>1650 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl11.jpg" alt="Kristal Damla Kolye" class="product-img">
    <div class="product-info">
        <h4>Kristal Damla Kolye</h4>
        <p>1450 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl12.jpg" alt="Işıltı Zincir Kolye" class="product-img">
    <div class="product-info">
        <h4>Işıltı Zincir Kolye</h4>
        <p>1450 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl13.jpg" alt="Melek Kanadı Kolye" class="product-img">
    <div class="product-info">
        <h4>Melek Kanadı Kolye</h4>
        <p>1450 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl14.jpg" alt="Vintage Motifli Kolye" class="product-img">
    <div class="product-info">
        <h4>Vintage Motifli Kolye</h4>
        <p>1450 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl15.jpg" alt="Nazar Boncuklu Zincir Kolye" class="product-img">
    <div class="product-info">
        <h4>Nazar Boncuklu Zincir Kolye</h4>
        <p>1450 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl16.jpg" alt="Çiçek Desenli Kolye" class="product-img">
    <div class="product-info">
        <h4>Çiçek Desenli Kolye</h4>
        <p>1450 ₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/kolye.images/kkl17.jpg" alt="Zarif İnci Kolye" class="product-img">
    <div class="product-info">
        <h4>Zarif İnci Kolye</h4>
        <p>1450 ₺</p>
    </div>
</div>

</div>
 </div>
            </section>
        </div>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>