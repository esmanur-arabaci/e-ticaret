<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arch Aksesuar | Şıklığın ve Estetiğin Buluşma Noktası</title>
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<?php include("includes/header.php"); ?>
    
    <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php" class="active">ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" >KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php">YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    <main class="container">
        
        <section class="hero-section">
            <img src="images/index.images/bileklik.jpg" alt="Öne Çıkan Ürün: Gümüş Zincir Bileklik ve Küpe Seti" class="hero-image">
        </section>

        <section class="product-gallery">
            <h2> ÖNE ÇIKAN GÜMÜŞ TAKILAR </h2> 
            
            <div class="product-grid">
                <div class="product-card">
                    <img src="images/index.images/unnamed (1).jpg" alt="Sade Gümüş Halka Küpe" class="product-img">
                    <div class="product-info">
                        <h4>Sade Gümüş Halka Küpe </h4>
                        <p>1.200 ₺</p>
                    </div>
                </div>
                <div class="product-card">
                    <img src="images/index.images/unnamed.jpg" alt="Burgu Zincir Siyah Uçlu Kolye" class="product-img">
                    <div class="product-info">
                        <h4>Burgu Zincir Siyah Uçlu Kolye</h4>
                        <p>1.700 ₺</p>
                    </div>
                </div>
                <div class="product-card">
                    <img src="images/index.images/bil.jpg" alt="İnce Küba Zincir Bileklik" class="product-img">
                    <div class="product-info">
                        <h4>İnce Küba Zincir Bileklik</h4>
                        <p>1.500 ₺</p>
                    </div>
                </div>
                <div class="product-card">
                    <img src="images/index.images/er.jpg" alt="Koral BileklikKatmanlı Küba Zincir Bileklik " class="product-img">
                    <div class="product-info">
                        <h4>Katmanlı Küba Zincir Bileklik</h4>
                        <p>1.200 ₺</p>
                    </div>
                </div>
                <div class="product-card">
                    <img src="images/index.images/images (2).jpeg" alt="Üç Renk Taşlı Küba Bileklik" class="product-img">
                    <div class="product-info">
                        <h4>Üç Renk Taşlı Küba Bileklik</h4>
                        <p>1.300 ₺</p>
                    </div>
                </div>
                <div class="product-card">
                    <img src="images/index.images/küpe.jpg" alt="Kare Formunda Siyah Taşlı Küpe" class="product-img">
                    <div class="product-info">
                        <h4>Kare Formunda Siyah Taşlı Küpe</h4>
                        <p>1.000 ₺</p>
                    </div>
                </div>
                <div class="product-card">
                    <img src="images/index.images/images (3).jpeg" alt="Klasik Halka Zincir Bileklik" class="product-img">
                    <div class="product-info">
                        <h4>Klasik Halka Zincir Bileklik</h4>
                        <p>1.000 ₺</p>
                    </div>
                </div>
                <div class="product-card">
                    <img src="images/index.images/zincirb.jpg" alt="Kare Siyah Oniks Uçlu Kolye" class="product-img">
                    <div class="product-info">
                        <h4>Çift Örgü Kalın Zincir Bileklik</h4>
                        <p>1.200 ₺</p>
                    </div>
                </div>
                <div class="product-card">
                    <img src="images/index.images/shopping.webp" alt="İnce İp Burgu Zincir Bileklik" class="product-img">
                    <div class="product-info">
                        <h4>İnce İp Burgu Zincir Bileklik</h4>
                        <p>1.100 ₺</p>
                    </div>
            </div>
        </section>

    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>