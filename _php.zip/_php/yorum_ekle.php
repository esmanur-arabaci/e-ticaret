<?php
session_start();
include 'db_baglanti.php'; 

// 1. POST Kontrolü
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['urun_id'])) {
    
    // 2. Verileri Al ve Temizle
    $urun_id = (int)$_POST['urun_id'];
    $yorum_yapan_ad = $baglanti->real_escape_string(trim($_POST['yorum_yapan_ad']));
    $yorum_metni = $baglanti->real_escape_string(trim($_POST['yorum_metni']));
    $puan = (int)$_POST['puan'];

    // 3. Geçerlilik Kontrolü
    if (empty($yorum_yapan_ad) || empty($yorum_metni) || $puan < 1 || $puan > 5) {
        $_SESSION['mesaj'] = "Hata: Lütfen adınızı, yorumunuzu ve geçerli bir puanı doldurun.";
        header("Location: urun_detay.php?id=" . $urun_id);
        exit();
    }

    // 4. Veri Tabanına Kayıt
    $sql = "INSERT INTO urun_yorumlar (urun_id, yorum_yapan_ad, yorum_metni, puan) VALUES (?, ?, ?, ?)";
    $sorgu = $baglanti->prepare($sql);
    
    // i: integer, s: string, s: string, i: integer
    $sorgu->bind_param("issi", $urun_id, $yorum_yapan_ad, $yorum_metni, $puan);
    
    if ($sorgu->execute()) {
        $_SESSION['mesaj'] = "Yorumunuz başarıyla gönderildi ve yayınlanmak üzere inceleniyor.";
    } else {
        $_SESSION['mesaj'] = "Hata: Yorumunuz kaydedilemedi. Lütfen tekrar deneyin.";
    }

    $sorgu->close();
    $baglanti->close();

    // Kullanıcıyı ürün detay sayfasına geri yönlendir
    header("Location: urun_detay.php?id=" . $urun_id);
    exit();
}

// POST isteği yoksa ana sayfaya yönlendir
header("Location: index.php");
exit();
?>