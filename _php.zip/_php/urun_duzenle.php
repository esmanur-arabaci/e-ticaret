<?php
// urun_duzenle.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_baglanti.php';

// Hangi ürünün düzenleneceğini ID üzerinden alıyoruz
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$sorgu = $baglanti->prepare("SELECT * FROM urunler WHERE id = ?");
$sorgu->bind_param("i", $id);
$sorgu->execute();
$sonuc = $sorgu->get_result();
$urun = $sonuc->fetch_assoc();

if (!$urun) {
    die("Ürün bulunamadı.");
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Ürün Düzenle - <?php echo htmlspecialchars($urun['urun_ad']); ?></title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main class="container" style="padding: 50px 0;">
        <h2>Ürün Bilgilerini Güncelle</h2>
        <p>Aşağıdaki alanları değiştirerek ürün açıklamasını güncelleyebilirsiniz.</p>
        
        <form action="urun_guncelle.php" method="POST" style="max-width: 600px; margin-top: 20px;">
            <input type="hidden" name="id" value="<?php echo $urun['id']; ?>">
            
            <div style="margin-bottom: 15px;">
                <label style="display: block; font-weight: bold;">Ürün Adı:</label>
                <input type="text" name="urun_ad" value="<?php echo htmlspecialchars($urun['urun_ad']); ?>" style="width: 100%; padding: 10px; border: 1px solid #ccc;">
            </div>
            
            <div style="margin-bottom: 15px;">
                <label style="display: block; font-weight: bold;">Ürün Açıklaması:</label>
                <textarea name="aciklama" rows="10" style="width: 100%; padding: 10px; border: 1px solid #ccc;"><?php echo htmlspecialchars($urun['aciklama']); ?></textarea>
            </div>
            
            <button type="submit" style="padding: 10px 20px; background-color: #27ae60; color: white; border: none; cursor: pointer; border-radius: 4px;">Değişiklikleri Kaydet</button>
            <a href="urun_detay.php?id=<?php echo $id; ?>" style="margin-left: 10px; color: #777; text-decoration: none;">İptal Et</a>
        </form>
    </main>
</body>
</html>