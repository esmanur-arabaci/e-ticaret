<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARCH AKSESUAR - SAAT KOLEKSİYONU</title>
    <link rel="stylesheet" href="style/style.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<?php include("includes/header.php"); ?>
    
    <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php" >ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" >KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php">YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php" class="active">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    
    <main>
        <div class="container">
            
            <section class="hero-section">
                <img src="images/saat.images/ss2.jpg" alt="Saat Koleksiyonu Vitrin Görseli" class="hero-image"> 
            </section>

            <section class="product-gallery">
                <h2>ÖZEL SAAT MODELLERİ</h2> 

                <div class="product-grid">
                    
<div class="product-card">
    <img src="images/saat.images/s1" alt="Siyah Beyaz Desenli Metal Kordonlu Kadın Saati" class="product-img">
    <div class="product-info">
        <h4>Desenli Metal Kordon</h4>
        <p>499.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/saat.images/s2" alt="Minimal Pembe Metal Kordon" class="product-img">
    <div class="product-info">
        <h4>Pembe Minimal Metal Kordon</h4>
        <p>349.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/saat.images/s3" alt="Siyah Pembe Kadranlı Spor Kordonlu Saat" class="product-img">
    <div class="product-info">
        <h4>Çizgili Kordonlu Spor Saat</h4>
        <p>699.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/saat.images/s4" alt="Altın Hasır Kordonlu Zarif Kadın Saati" class="product-img">
    <div class="product-info">
        <h4>Altın Hasır Kordon</h4>
        <p>425.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/saat.images/s5" alt="Dijital Ekranlı Altın Tonlu Retro Saat" class="product-img">
    <div class="product-info">
        <h4>Altın Retro Dijital Saat</h4>
        <p>299.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/saat.images/s11" alt="Altın Dikdörtgen Kadranlı Metal Bilezik Saat" class="product-img">
    <div class="product-info">
        <h4>Altın Dikdörtgen Bilezik Saat</h4>
        <p>550.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s12" alt="Altın Zincir Kordonlu Bordo Taşlı Saat" class="product-img">
    <div class="product-info">
        <h4>Altın Kordon Bordo Taşlı Saat</h4>
        <p>470.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s13" alt="Altın Kordonlu Şeffaf Taş Detaylı Saat" class="product-img">
    <div class="product-info">
        <h4>Altın Kordon Şeffaf Taşlı Saat</h4>
        <p>470.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/saat.images/s15" alt="Altın Kordonlu Lacivert Taş Detaylı Saat" class="product-img">
    <div class="product-info">
        <h4>Altın Kordon Lacivert Taşlı Saat</h4>
        <p>470.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s16" alt="Altın Mini Zincir Kordonlu Zarif Saat" class="product-img">
    <div class="product-info">
        <h4>Altın Mini Zincir Kordon Saat</h4>
        <p>450.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s17" alt="Gümüş Zincir Kordonlu Oval Kadran Saat" class="product-img">
    <div class="product-info">
        <h4>Gümüş İnce Zincir Kordon Saat</h4>
        <p>450.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s18" alt="Altın Kare Kadranlı Metal Kordonlu Saat" class="product-img">
    <div class="product-info">
        <h4>Gümüş Oval Kadranlı Metal Saat</h4>
        <p>550.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s19" alt="Gümüş Dikdörtgen Kadranlı Metal Kordon Saat" class="product-img">
    <div class="product-info">
        <h4>Altın Dikdörtgen Metal Saat</h4>
        <p>550.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s20" alt="Gümüş Zincir Kordonlu Siyah Kadran Saat" class="product-img">
    <div class="product-info">
        <h4>Gümüş Siyah Kadranlı Zincir Saat</h4>
        <p>470.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s21" alt="Gümüş İnce Zincir Kordonlu Saat" class="product-img">
    <div class="product-info">
        <h4>Gümüş İnce Zincir Kordon Saat</h4>
        <p>450.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s22" alt="Gümüş İnce Taş Detaylı Zincir Saat" class="product-img">
    <div class="product-info">
        <h4>Gümüş Taş Detaylı Zincir Saat</h4>
        <p>470.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s23" alt="Gümüş Kordonlu Yuvarlak Kadran Mini Saat" class="product-img">
    <div class="product-info">
        <h4>Gümüş Yuvarlak Kadran Mini Saat</h4>
        <p>430.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s24" alt="Gümüş Zincir Kordonlu Taş Detaylı Saat" class="product-img">
    <div class="product-info">
        <h4>Gümüş Zincir Kordon Taşlı Saat</h4>
        <p>470.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s25" alt="Gümüş İnce Zincir Kordonlu Oval Saat" class="product-img">
    <div class="product-info">
        <h4>Gümüş İnce Zincir Oval Saat</h4>
        <p>430.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s26" alt="Gümüş Taş Detaylı Zincir Mini Saat" class="product-img">
    <div class="product-info">
        <h4>Gümüş Taş Detaylı Mini Saat</h4>
        <p>470.0₺</p>
    </div>
</div>
<div class="product-card">
    <img src="images/saat.images/s27" alt="Gümüş Tek Sıra Zincir Kordonlu Mini Saat" class="product-img">
    <div class="product-info">
        <h4>Gümüş Tek Sıra Zincir Mini Saat</h4>
        <p>450.0₺</p>
    </div>
</div>
            </section>
        </div>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>