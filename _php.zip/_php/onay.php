<?php
session_start();
include 'db_baglanti.php';

// 1. Kullanıcı ve Sepet Kontrolü
if (!isset($_SESSION['oturum_basarili']) || !isset($_SESSION['sepet']) || empty($_SESSION['sepet'])) {
    // Sepet boşsa veya giriş yapılmamışsa ana sayfaya yönlendir
    header('Location: index.php');
    exit();
}

$kullanici_id = $_SESSION['kullanici_id'];
$sepet = $_SESSION['sepet'];
$hata_mesaji = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // 2. POST Verilerini Al (MySQLi/Real Escape String ile güvenlik sağlanır)
    $ad_soyad = $baglanti->real_escape_string($_POST['ad_soyad']);
    $adres = $baglanti->real_escape_string($_POST['adres']);
    $sehir = $baglanti->real_escape_string($_POST['il']);
    $telefon = $baglanti->real_escape_string($_POST['telefon']);
    $odeme_yontemi = $baglanti->real_escape_string($_POST['odeme_yontemi']);
    $genel_toplam = (float)$_POST['genel_toplam']; 

    // --- Başlangıç: İşlem Güvenliği (Transaction) ---
    // Eğer bir sorgu başarısız olursa, önceki tüm değişiklikler geri alınır.
    $baglanti->begin_transaction(); 

    try {
        // 3. Adım: Genel Siparişi Kaydet (siparisler tablosu)
        $sql_siparis = "INSERT INTO siparisler (kullanici_id, genel_toplam, ad_soyad, adres, sehir, telefon, odeme_yontemi) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $sorgu_siparis = $baglanti->prepare($sql_siparis);
        
        // i: integer, d: decimal/float, s: string (x5)
        $sorgu_siparis->bind_param("idsssss", $kullanici_id, $genel_toplam, $ad_soyad, $adres, $sehir, $telefon, $odeme_yontemi);
        
        if (!$sorgu_siparis->execute()) {
            throw new Exception("Sipariş ana kaydı oluşturulamadı: " . $sorgu_siparis->error);
        }

        // Yeni oluşturulan siparişin ID'sini al
        $yeni_siparis_id = $baglanti->insert_id;
        $sorgu_siparis->close();

        // 4. Adım: Sipariş Detaylarını Kaydet (siparis_detay tablosu)
        $sql_detay = "INSERT INTO siparis_detay (siparis_id, urun_id, adet, fiyat) VALUES (?, ?, ?, ?)";
        $sorgu_detay = $baglanti->prepare($sql_detay);
        
        // Güvenlik: Sepetteki ürünlerin güncel fiyatlarını veri tabanından çek
        $id_listesi = implode(',', array_keys($sepet));
        $fiyat_sorgu = $baglanti->query("SELECT id, fiyat FROM urunler WHERE id IN ($id_listesi)");
        
        $fiyatlar = [];
        if ($fiyat_sorgu) {
            while($f = $fiyat_sorgu->fetch_assoc()) {
                $fiyatlar[$f['id']] = $f['fiyat'];
            }
        }

        foreach ($sepet as $urun_id => $adet) {
            // Fiyat kontrolü
            if (!isset($fiyatlar[$urun_id])) {
                 throw new Exception("Sepetteki bir ürünün fiyat bilgisi bulunamadı.");
            }
            $urun_fiyati = $fiyatlar[$urun_id];
            
            // i: integer (x2), d: double/float (x2)
            $sorgu_detay->bind_param("iidd", $yeni_siparis_id, $urun_id, $adet, $urun_fiyati);
            
            if (!$sorgu_detay->execute()) {
                throw new Exception("Sipariş detay kaydı oluşturulamadı: " . $sorgu_detay->error);
            }
        }
        $sorgu_detay->close();

        // --- Başarılı Sonuç ---
        $baglanti->commit(); // Tüm işlemleri kalıcı olarak kaydet
        $_SESSION['sepet'] = []; // Sepeti temizle
        $_SESSION['onay_mesaj'] = "Tebrikler! Siparişiniz başarıyla alındı.";
        header("Location: onay_sayfasi.php?siparis_id=" . $yeni_siparis_id);
        exit();

    } catch (Exception $e) {
        // --- Hata Sonucu ---
        $baglanti->rollback(); // Hata olursa tüm değişiklikleri geri al
        $hata_mesajim = "Siparişiniz kaydedilirken bir hata oluştu: " . $e->getMessage();
    }
}

// Hata oluşursa kullanıcıyı ödeme sayfasına geri gönder
if (!empty($hata_mesajim)) {
    $_SESSION['mesaj'] = $hata_mesajim;
    header('Location: odeme.php');
    exit();
}

$baglanti->close();
?>