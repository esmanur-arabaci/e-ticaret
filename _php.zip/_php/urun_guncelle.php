<?php
// urun_guncelle.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include 'db_baglanti.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    $yeni_ad = $baglanti->real_escape_string($_POST['urun_ad']);
    $yeni_aciklama = $baglanti->real_escape_string($_POST['aciklama']);

    // SQL UPDATE komutu ile veriyi güncelliyoruz
    $sql = "UPDATE urunler SET urun_ad = ?, aciklama = ? WHERE id = ?";
    $stmt = $baglanti->prepare($sql);
    $stmt->bind_param("ssi", $yeni_ad, $yeni_aciklama, $id);

    if ($stmt->execute()) {
        $_SESSION['mesaj'] = "Ürün başarıyla güncellendi.";
        header("Location: urun_detay.php?id=" . $id);
    } else {
        echo "Hata oluştu: " . $baglanti->error;
    }
    
    $stmt->close();
}
$baglanti->close();
?>