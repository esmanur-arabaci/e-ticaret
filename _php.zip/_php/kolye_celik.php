<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arch Aksesuar | Şıklığın ve Estetiğin Buluşma Noktası</title>
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<?php include("includes/header.php"); ?>
        <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php">ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php" class="active">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php">KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php">YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    
    <main>
        <div class="container">
            
                <div class="product-grid">
                    
                    <div class="product-card">
                        <img src="images/kolye.images/kk33.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Kristal Halkalı Çelik Kolye</h4>

                            <p>450 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/kk32.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Yıldız Detaylı Çelik Kolye</h4>
                            <p>500 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/kk31.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Halka Uçlu Zincir Kolye</h4>
                            <p>500 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/kk34.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Y Modeelli Çelik kolye</h4>
                            <p>450 ₺</p>
                        </div>
                    </div>
                    
                    <div class="product-card">
                        <img src="images/kolye.images/kk35.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Kalın Halkalı Zincir Kolye</h4>
                            <p>450 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/kk36.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Taş Detaylı Altın Renk Kolye</h4>
                            <p>455 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/kk27.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Çift Sıra Zincir</h4>
                            <p>450 ₺</p>
                        </div>
                    </div>
                    
                    <div class="product-card">
                        <img src="images/kolye.images/kk26.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Kalın Zincir Kolye </h4>                    
                            <p>500 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/kk25.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Balık Figürlü Nazar Kolye</h4>
                            <p>550 ₺</p>
                        </div>
                    </div>
                    <div class="product-card">
                        <img src="images/kolye.images/kk24.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>İnce Zincir Turkuaz Kolye</h4>
                            <p>500 ₺</p>
                        </div>
                    </div>


                    <div class="product-card">
                        <img src="images/kolye.images/kk21.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Nazar Boncuklu Kolye</h4>

                            <p>550 ₺</p>
                        </div>
                    </div>
                    
                    <div class="product-card">
                        <img src="images/kolye.images/kk20.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Taşlı Plaka Zincir Kolye</h4>
                            <p>350 ₺</p>
                        </div>
                    </div>



                     <div class="product-card">
                        <img src="images/kolye.images/kk12.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Minimal İnci Uçlu Kolye</h4>
                            <p>350 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/kk10.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Nazar Gözlü Plaka Kolye</h4>
                            <p>400 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/kk9.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>İkili İnci Zincir Kolye</h4>
                            <p>400 ₺</p>
                        </div>
                    </div>
                    
                    <div class="product-card">
                        <img src="images/kolye.images/kk8.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Halka Detaylı Zincir Kolye</h4>
                            <p>400 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/kk7.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Çiçek Motifli Kolye</h4>
                            <p>400TL </p>
                        </div>
                    </div>
                                        <div class="product-card">
                        <img src="images/kolye.images/kk6.webp" alt="" class="product-img">
                        <div class="product-info">
                            <h4>Minimal Yıldız Kolye</h4>
                            <p>350 ₺</p>
                        </div>
                    </div>
                    
                    </div>
            </section>
        </div>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>