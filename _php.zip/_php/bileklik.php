<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARCH AKSESUAR - BİLEKLİK KOLEKSİYONU</title>
    <link rel="stylesheet" href="style/style.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<?php include("includes/header.php"); ?>
    
    <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php" >ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" >KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php" class="active">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php">YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    
    <main>
        <div class="container">
            
            <section class="hero-section">
                <img src="images/bileklik.images/bb2.jpg" alt="Bileklik Koleksiyonu Vitrin Görseli" class="hero-image"> 
            </section>

            <section class="product-gallery">
                <h2>ÖZEL BİLEKLİK TASARIMLARI</h2> 
 <div class="product-grid">
            <div class="product-card">
                    <img src="images/bileklik.images/b1" alt="Kalın Zincir Bileklik" class="product-img">
                    <div class="product-info">
                        <h4>Kalın Zincir</h4>
                        <p>135.0₺</p>
                    </div>
                </div>

                <div class="product-card">
                    <img src="images/bileklik.images/b2" alt="Minimal İnce Zincir Bileklik" class="product-img">
                    <div class="product-info">
                        <h4>Minimal İnce Zincir</h4>
                        <p>89.0₺</p>
                    </div>
                </div>

                <div class="product-card">
                    <img src="images/bileklik.images/b3" alt="Taşlı Halka Bileklik" class="product-img">
                    <div class="product-info">
                        <h4>Zirkon Halka</h4>
                        <p>155.0₺</p>
                    </div>
                </div>

                <div class="product-card">
                    <img src="images/bileklik.images/b4" alt="Örgü Deri Bileklik" class="product-img">
                    <div class="product-info">
                        <h4>Örgü Deri</h4>
                        <p>110.0₺</p>
                    </div>
                </div>
                
                <div class="product-card">
                    <img src="images/bileklik.images/b5" alt="Sade Kelepçe Bileklik" class="product-img">
                    <div class="product-info">
                        <h4>Sade Kelepçe</h4>
                        <p>180.0₺</p>
                    </div>
                </div>

                <div class="product-card">
                    <img src="images/bileklik.images/b6" alt="İpli Şans Bilekliği" class="product-img">
                    <div class="product-info">
                        <h4>İpli Şans</h4>
                        <p>65.0₺</p>
                    </div>
                </div>
                
                <div class="product-card">
                    <img src="images/bileklik.images/b7" alt="İpli Şans Bilekliği" class="product-img">
                    <div class="product-info">
                        <h4>İpli Şans</h4>
                        <p>65.0₺</p>
                    </div>
                </div>

                <div class="product-card">
                    <img src="images/bileklik.images/b8" alt="İpli Şans Bilekliği" class="product-img">
                    <div class="product-info">
                        <h4>İpli Şans</h4>
                        <p>65.0₺</p>
                    </div>
                </div>

                <div class="product-card">
                    <img src="images/bileklik.images/b9" alt="İpli Şans Bilekliği" class="product-img">
                    <div class="product-info">
                        <h4>İpli Şans</h4>
                        <p>65.0₺</p>
                    </div>
                </div>
                <div class="product-card">
                    <img src="images/bileklik.images/b10" alt="İpli Şans Bilekliği" class="product-img">
                    <div class="product-info">
                        <h4>İpli Şans</h4>
                        <p>65.0₺</p>
                    </div>
                    </div>
             </div>
            </section>
        </div>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>