<?php
session_start();
include 'db_baglanti.php';

// Hata mesajlarını saklayacak değişken
$hata_mesaji = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. POST verilerini al (HTML form adlarına göre: email, password)
    // NOT: Prepared Statement kullandığımız için real_escape_string GEREKMEZ ve HATA VERİR!
    $eposta = $_POST['email']; 
    $sifre = $_POST['password'];

    // 2. E-postaya göre kullanıcıyı veri tabanından çek
    $sorgu = $baglanti->prepare("SELECT id, ad_soyad, sifre FROM kullanicilar WHERE eposta = ?");
    
    // Bağlantınız MySQLi ise, bind_param kullanırız
    if ($sorgu) {
        $sorgu->bind_param("s", $eposta);
        $sorgu->execute();
        $sonuc = $sorgu->get_result();
    
        if ($sonuc->num_rows == 1) {
            $kullanici = $sonuc->fetch_assoc();
    
            // 3. Şifreleri Kontrol Et (Hashlenmiş şifreyi kontrol et)
            if (password_verify($sifre, $kullanici['sifre'])) {
                // Şifre doğru, oturum başlat ve ana sayfaya yönlendir!
                $_SESSION['oturum_basarili'] = true;
                $_SESSION['kullanici_id'] = $kullanici['id'];
                $_SESSION['ad_soyad'] = $kullanici['ad_soyad'];
    
                // BAŞARILI YÖNLENDİRME
                header("Location: index.php"); 
                exit(); 
            } else {
                // Şifre yanlış
                $hata_mesaji = "Hata: E-posta veya şifre hatalı.";
            }
        } else {
            // Kullanıcı bulunamadı
            $hata_mesaji = "Hata: E-posta veya şifre hatalı.";
        }
    
        $sorgu->close();
    } else {
        $hata_mesaji = "Veri tabanı sorgu hatası: " . $baglanti->error;
    }
}

$baglanti->close();

// Hata varsa, oturuma mesajı ata ve giriş formuna geri yönlendir
if (!empty($hata_mesaji)) {
    // Mesajı oturuma atıyoruz
    $_SESSION['login_hata'] = $hata_mesaji;
    // Kullanıcıyı giriş sayfasına geri yönlendir
    header("Location: giris.php"); 
    exit();
}

?>