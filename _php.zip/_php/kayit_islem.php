<?php
session_start();
include 'db_baglanti.php';

// Hata mesajı için değişken
$hata_mesaji = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$ad_soyad = $_POST['name']; 
// Formdan gelen 'email' -> veri tabanındaki 'eposta' sütununa gider.
$eposta = $_POST['email'];
// Formdan gelen 'password' -> veri tabanındaki 'sifre' sütununa gider.
$sifre = $_POST['password'];
    // Güvenlik Kontrolü: Şifre boş mu?
    if (empty($ad_soyad) || empty($eposta) || empty($sifre)) {
        $hata_mesaji = "Hata: Lütfen tüm alanları doldurunuz.";
    }

    if (empty($hata_mesaji)) {
        
        // 2. Şifreyi GÜVENLİ bir şekilde HASHLE
        $hashli_sifre = password_hash($sifre, PASSWORD_DEFAULT);

        // 3. E-posta'nın daha önce kullanılıp kullanılmadığını kontrol et
        $kontrol_sorgu = $baglanti->prepare("SELECT id FROM kullanicilar WHERE eposta = ?");
        $kontrol_sorgu->bind_param("s", $eposta);
        $kontrol_sorgu->execute();
        $kontrol_sorgu->store_result();

        if ($kontrol_sorgu->num_rows > 0) {
            // Hata: Bu e-posta zaten kayıtlı
            $hata_mesaji = "Hata: Bu e-posta adresi zaten kullanılıyor.";
        } else {
            // 4. Kullanıcıyı veri tabanına ekle (Prepared Statement ile güvenli ekleme)
            $ekle_sorgu = $baglanti->prepare("INSERT INTO kullanicilar (ad_soyad, eposta, sifre) VALUES (?, ?, ?)");
            $ekle_sorgu->bind_param("sss", $ad_soyad, $eposta, $hashli_sifre);

            if ($ekle_sorgu->execute()) {
                $_SESSION['kayit_mesaji'] = "Kayıt Başarılı! Şimdi giriş yapabilirsiniz.";
                header("Location: giris.php"); // Başarılıysa giriş sayfasına yönlendir
                exit();
            } else {
                $hata_mesaji = "Hata: Kayıt sırasında bir hata oluştu. (" . $baglanti->error . ")";
            }
            $ekle_sorgu->close();
        }
        $kontrol_sorgu->close();
    }
}

// Hata varsa, mesajı session'a ata ve kayıt formuna geri yönlendir
if (!empty($hata_mesaji)) {
    $_SESSION['kayit_mesaji'] = $hata_mesaji;
    header("Location: uye_ol.php"); 
    exit();
}
$baglanti->close();
?>