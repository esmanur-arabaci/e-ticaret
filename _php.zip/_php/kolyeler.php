<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARCH AKSESUAR - KOLYE KOLEKSİYONU</title>
    <link rel="stylesheet" href="style/style.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<?php include("includes/header.php"); ?>
    
    <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php">ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php" class="active">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php">KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php">YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>

                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>                    
                </ul>
            </div>
        </div>
    </nav>
    
    <main>
        <div class="container">
            
            <section class="hero-section">
                <img src="images/kolye.images/k1.jpg" alt="Kolye Koleksiyonu Vitrin Görseli" class="hero-image">
            </section>

            <section class="product-gallery">
                <h2>ÖZEL KOLYE TASARIMLARI</h2> 

                <div class="product-grid">
                    
                    <div class="product-card">
                        <img src="images/kolye.images/k2.webp" alt="Özel Seri Kolye Kombinleri" class="product-img">
                        <div class="product-info">
                            <h4>Özel Seri Kolye Kombinleri</h4>
                            <p>1.100 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/k3.webp" alt="Özel Seri Kolye Kombinleri" class="product-img">
                        <div class="product-info">
                            <h4>Özel Seri Kolye Kombinleri</h4>
                            <p>1.200 ₺</p>
                        </div>
                    </div>
                    <div class="product-card">
                        <img src="images/kolye.images/k8.webp" alt="Özel Seri Kolye Kombinleri" class="product-img">
                        <div class="product-info">
                            <h4>Özel Seri Kolye Kombinleri</h4>
                            <p>1.200 ₺p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/k9.webp" alt="Özel Seri Kolye Kombinleri" class="product-img">
                        <div class="product-info">
                            <h4>Özel Seri Kolye Kombinleri</h4>
                            <p>1.400 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/k10.webp" alt="Özel Seri Kolye Kombinleri" class="product-img">
                        <div class="product-info">
                            <h4>Özel Seri Kolye Kombinleri</h4>
                            <p>900 ₺</p>
                        </div>
                    </div>
                    
                    <div class="product-card">
                        <img src="images/kolye.images/k11.webp" alt="Özel Seri Kolye Kombinleri" class="product-img">
                        <div class="product-info">
                            <h4>Özel Seri Kolye Kombinleri</h4>
                            <p>950 ₺</p>
                        </div>
                    </div>


                    <div class="product-card">
                        <img src="images/kolye.images/k12.webp" alt="Özel Seri Kolye Kombinleri" class="product-img">
                        <div class="product-info">
                            <h4>Özel Seri Kolye Kombinleri</h4>
                            <p>1.000 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/k13.webp" alt="Özel Seri Kolye Kombinleri" class="product-img">
                        <div class="product-info">
                            <h4>Özel Seri Kolye Kombinleri</h4>
                            <p>1.200 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/k14.webp" alt="Özel Seri Kolye Kombinleri" class="product-img">
                        <div class="product-info">
                            <h4>Özel Seri Kolye Kombinleri</h4>
                            <p>1.300 ₺</p>
                        </div>
                    </div>

                    <div class="product-card">
                        <img src="images/kolye.images/k15.webp" alt="Özel Seri Kolye Kombinleri" class="product-img">
                        <div class="product-info">
                            <h4>Özel Seri Kolye Kombinleri</h4>
                            <p>1.100 ₺</p>
                        </div>
                    </div>
                    
                    <div class="product-card">
                        <img src="images/kolye.images/k16.webp" alt="Özel Seri Kolye Kombinleri" class="product-img">
                        <div class="product-info">
                            <h4>Özel Seri Kolye Kombinleri</h4>
                            <p>900 ₺</p>
                        </div>
                    </div>

                    </div>
                    
                    </div>
            </section>
        </div>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>