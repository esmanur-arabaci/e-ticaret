<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arch Aksesuar | Şıklığın ve Estetiğin Buluşma Noktası</title>
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<?php include("includes/header.php"); ?>
        <nav>
        <div class="main-menu">
            <div class="container">
                <ul>
                    <li><a href="index.php">ANA SAYFA</a></li>

                    <li>
                        <a href="kolyeler.php">KOLYELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kolye_celik.php">Çelik Kolyeler</a>
                            <a href="kolye_gumus.php">Gümüş Kolyeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="kupe.php" class="active">KÜPELER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="kupe_celik.php">Çelik Küpeler</a>
                            <a href="kupe_gumus.php">Gümüş Küpeler</a>
                        </div>
                    </li>

                    <li>
                        <a href="bileklik.php">BİLEKLİKLER <i class="fa-solid fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="bileklik_celik.php">Çelik Bileklikler</a>
                            <a href="bileklik_gumus.php">Gümüş Bileklikler</a>
                        </div>
                    </li>
                    
                    <li>
                        <a href="yuzuk.php">YÜZÜKLER </a>

                    </li>
                    
                    <li>
                        <a href="saat.php">SAATLER </a>

                    </li>
                    <li>
                        <a href="sahmeran.php"> ŞAHMERAN</a>

                    </li>  
                </ul>
            </div>
        </div>
    </nav>
    
    <main>
        <div class="container">
            
                <div class="product-grid">
                    
<div class="product-card">
    <img src="images/küpe.images/kç1.webp" alt="Taşlı Yıldız Küpe" class="product-img">
    <div class="product-info">
        <h4>Taşlı Yıldız Küpe</h4>
        <p>89.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç2.webp" alt="Çoklu Taşlı Mini Küpe Seti" class="product-img">
    <div class="product-info">
        <h4>Çoklu Taşlı Mini Küpe Seti</h4>
        <p>128.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç3.webp" alt="Taşlı Earcuff ve Halka Küpe Seti" class="product-img">
    <div class="product-info">
        <h4>Taşlı Earcuff ve Halka Küpe Seti</h4>
        <p>145.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç4.webp" alt="Zirkon Taşlı Minimal Halka Küpe" class="product-img">
    <div class="product-info">
        <h4>Zirkon Taşlı Minimal Halka Küpe</h4>
        <p>110.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç5.webp" alt="Chunky Kalın Halka Küpe" class="product-img">
    <div class="product-info">
        <h4>Chunky Kalın Halka Küpe</h4>
        <p>95.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç6.webp" alt="Zincir Detaylı Püsküllü Küpe" class="product-img">
    <div class="product-info">
        <h4>Zincir Detaylı Püsküllü Küpe</h4>
        <p>165.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç7.webp" alt="Minimalist Yıldız Stud Küpe" class="product-img">
    <div class="product-info">
        <h4>Minimalist Yıldız Stud Küpe</h4>
        <p>98.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç8.webp" alt="Sade Mini Kalın Halka Küpe" class="product-img">
    <div class="product-info">
        <h4>Sade Mini Kalın Halka Küpe</h4>
        <p>120.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç9.webp" alt="Kıvrımlı Düzensiz Küpe Seti" class="product-img">
    <div class="product-info">
        <h4>Kıvrımlı Düzensiz Küpe Seti</h4>
        <p>135.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç10.webp" alt="Yaprak Figürlü Tırmanıcı Küpe" class="product-img">
    <div class="product-info">
        <h4>Yaprak Figürlü Tırmanıcı Küpe</h4>
        <p>112.0₺</p>
    </div>
</div>



<div class="product-card">
    <img src="images/küpe.images/kç14.webp" alt="Kıvrımlı Yılan Figürlü Küpe" class="product-img">
    <div class="product-info">
        <h4>Kıvrımlı Yılan Figürlü Küpe</h4>
        <p>128.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç15.webp" alt="Burmalı Mini Halka Küpe" class="product-img">
    <div class="product-info">
        <h4>Burmalı Mini Halka Küpe</h4>
        <p>146.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç16.webp" alt="Renkli Zincir Charm Küpe" class="product-img">
    <div class="product-info">
        <h4>Renkli Zincir Charm Küpe</h4>
        <p>115.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç17.webp" alt="Emaye Detaylı Kalın Zincir Küpe" class="product-img">
    <div class="product-info">
        <h4>Emaye Detaylı Kalın Zincir Küpe</h4>
        <p>96.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç18.webp" alt="Sade Mini Halka Küpe" class="product-img">
    <div class="product-info">
        <h4>Sade Mini Halka Küpe</h4>
        <p>162.0₺</p>
    </div>
</div>


<div class="product-card">
    <img src="images/küpe.images/kç24.webp" alt="Çift Tonlu Yıldız Küpe" class="product-img">
    <div class="product-info">
        <h4>Çift Tonlu Yıldız Küpe</h4>
        <p>165.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç25.webp" alt="Midye Kabuğu Dokulu Küpe" class="product-img">
    <div class="product-info">
        <h4>Midye Kabuğu Dokulu Küpe</h4>
        <p>89.0₺</p>
    </div>
</div>

<div class="product-card">
    <img src="images/küpe.images/kç26.webp" alt="Taşlı Yaprak Tırmanıcı Küpe" class="product-img">
    <div class="product-info">
        <h4>Taşlı Yaprak Tırmanıcı Küpe</h4>
        <p>128.0₺</p>
    </div>
</div>

</div>
            </section>
        </div>
    </main>

<?php include("includes/footer.php"); ?>
</body>
</html>