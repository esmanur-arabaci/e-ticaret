<?php
session_start();

if (!isset($_SESSION['onay_mesaj'])) {
    header('Location: index.php');
    exit();
}

$onay_mesaji = $_SESSION['onay_mesaj'];
unset($_SESSION['onay_mesaj']); 
$siparis_id = htmlspecialchars($_GET['siparis_id'] ?? 'Bilinmiyor');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Siparişiniz Onaylandı - Arch Aksesuar</title>
    <link rel="stylesheet" href="style/style.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<?php include("includes/header.php"); ?>

<main class="container" style="padding: 100px 0; text-align: center;">
    <div style="max-width: 600px; margin: 0 auto; padding: 40px; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
        
        <h2 style="color: #27ae60; font-size: 2.5em; margin-bottom: 20px;">
            <i class="fas fa-check-circle" style="margin-right: 10px;"></i> Siparişiniz Alındı!
        </h2>
        
        <p style="font-size: 1.2em; margin-bottom: 30px; line-height: 1.6;"><?php echo $onay_mesaji; ?></p>
        
        <p style="font-size: 1.1em; font-weight: bold; margin-bottom: 50px;">
            Sipariş Takip Numaranız: <span style="color: var(--color-accent); font-size: 1.2em;"><?php echo $siparis_id; ?></span>
        </p>
        
        <a href="index.php" style="padding: 12px 35px; background-color: var(--color-accent); color: white; border-radius: 5px; text-decoration: none; font-weight: bold; transition: background-color 0.3s;">
            Ana Sayfaya Dön
        </a>
    </div>
</main>

<?php include("includes/footer.php"); ?>
</body>
</html>